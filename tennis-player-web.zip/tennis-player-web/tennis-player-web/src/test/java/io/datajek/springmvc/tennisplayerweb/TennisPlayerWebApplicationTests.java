package io.datajek.springmvc.tennisplayerweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TennisPlayerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
